package p01BrowserCheck20260925;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@SpringBootApplication
@EnableMethodSecurity(jsr250Enabled = true)
@ComponentScan(basePackages = {"bitecode.modules", "p01BrowserCheck20260925"})
@EnableJpaRepositories(basePackages = {"bitecode.modules", "p01BrowserCheck20260925"})
@EntityScan(basePackages = {"bitecode.modules", "p01BrowserCheck20260925"})
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
